#ifndef exo4
#define exo4

int *saisie(int taille);
//void ajout_fin(int *a, int *b, int *taille1, int taille2);
int* ajout_fin(int *a, int *b, int taille1, int taille2, int *taille3);
void del_occ(int *t, int *taille, int x);
void affiche(int *t, int taille);

#endif